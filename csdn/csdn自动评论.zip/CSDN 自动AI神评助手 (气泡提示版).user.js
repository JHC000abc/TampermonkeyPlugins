// ==UserScript==
// @name         CSDN 自动AI神评助手 (气泡提示版)
// @namespace    http://tampermonkey.net/
// @version      7.1
// @description  修正400错误 -> 延长超时 -> 深度清洗DeepSeek思考标签 -> 气泡提示
// @author       Gemini Assistant
// @match        https://blog.csdn.net/*/article/details/*
// @match        https://*.blog.csdn.net/article/details/*
// @connect      172.17.0.1
// @connect      127.0.0.1
// @connect      localhost
// @connect      blog.csdn.net
// @grant        GM_xmlhttpRequest
// @grant        GM_cookie
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    // ================= 🔧 配置区域 =================
    const CONFIG = {
        // AI 地址 (Windows本地请用 127.0.0.1)
        aiApiUrl: "http://172.17.0.1:11434/api/generate",
        aiModel: "deepseek-r1:1.5b",

        // AI 提示词
        aiSystemPrompt: "你是一个技术博主。请阅读下文，写一句100字以内的专业评论，要对作者带有鼓励性质，要写出自己的真实评论，不要让人看着像ai生成的评论，评论风格要幽默风趣，不要呆板。直接输出内容：",

        // CSDN 接口
        submitUrl: "https://blog.csdn.net/phoenix/web/v1/comment/submit",

        // 超时设置
        aiTimeout: 60000,
        startDelay: 3000
    };

    // ================= 🎨 UI 交互函数 (新增) =================

    /**
     * 显示气泡提示 (Toast)
     * @param {string} message - 提示内容
     * @param {string} type - 类型: 'success' (绿色), 'error' (红色), 'info' (蓝色)
     * @param {number} duration - 持续时间 (毫秒)，默认3000ms
     */
    function showToast(message, type = 'info', duration = 3000) {
        // 1. 创建容器
        const toast = document.createElement('div');
        toast.innerText = message;

        // 2. 基础样式 (使用内联样式以减少依赖)
        Object.assign(toast.style, {
            position: 'fixed',
            top: '30px',             // 距离顶部 30px
            left: '50%',             // 水平居中
            transform: 'translateX(-50%) translateY(-20px)', // 初始位置略微上移，用于动画
            zIndex: '999999',        // 确保在 CSDN 导航栏之上
            padding: '12px 24px',
            borderRadius: '8px',
            color: '#fff',
            fontSize: '15px',
            fontWeight: '500',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
            boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            opacity: '0',            // 初始透明
            transition: 'all 0.4s cubic-bezier(0.18, 0.89, 0.32, 1.28)', // 弹性动画
            pointerEvents: 'none'    // 点击穿透，不影响下方操作
        });

        // 3. 根据类型设置背景色
        if (type === 'success') {
            toast.style.backgroundColor = '#2ecc71'; // 成功绿
            toast.style.borderLeft = '5px solid #27ae60';
        } else if (type === 'error') {
            toast.style.backgroundColor = '#e74c3c'; // 错误红
            toast.style.borderLeft = '5px solid #c0392b';
        } else {
            toast.style.backgroundColor = '#3498db'; // 信息蓝
            toast.style.borderLeft = '5px solid #2980b9';
        }

        // 4. 插入 DOM
        document.body.appendChild(toast);

        // 5. 执行进场动画 (下一帧执行以触发 transition)
        requestAnimationFrame(() => {
            toast.style.opacity = '1';
            toast.style.transform = 'translateX(-50%) translateY(0)';
        });

        // 6. 设置定时销毁
        setTimeout(() => {
            // 退场动画
            toast.style.opacity = '0';
            toast.style.transform = 'translateX(-50%) translateY(-20px)';

            // 动画结束后从 DOM 移除
            setTimeout(() => {
                if(document.body.contains(toast)) {
                    document.body.removeChild(toast);
                }
            }, 1000); // 等待 CSS transition 结束
        }, duration);
    }

    // ================= 🛠️ 逻辑工具函数 =================

    // 1. 获取文章ID
    function getArticleId() {
        const match = location.pathname.match(/\/details\/(\d+)/);
        return match ? match[1] : null;
    }

    // 2. 检查登录状态
    function checkLoginStatus() {
        // 简单检查 Cookie 是否存在，更严谨的检查需要验证 UserToken
        return document.cookie.length > 0;
    }

    // 3. 提取正文
    function extractContent() {
        const box = document.querySelector('.blog-content-box');
        if (box) {
            box.style.border = "5px solid #2ecc71"; // 绿色边框表示锁定成功
            return box.innerText.substring(0, 1000).replace(/\s+/g, ' ');
        }
        return null;
    }

    // 4. 请求 AI (含 DeepSeek 清洗)
    function getAIResponse(articleText) {
        return new Promise((resolve, reject) => {
            showToast('🧠 AI 正在阅读并思考...', 'info', 5000); // 提示用户正在运行
            console.log(`🧠 [AI] 正在思考... (超时设置: ${CONFIG.aiTimeout/1000}s)`);

            GM_xmlhttpRequest({
                method: "POST",
                url: CONFIG.aiApiUrl,
                headers: { "Content-Type": "application/json" },
                data: JSON.stringify({
                    "model": CONFIG.aiModel,
                    "prompt": `${CONFIG.aiSystemPrompt}\n\n【文章片段】\n${articleText}`,
                    "stream": false
                }),
                timeout: CONFIG.aiTimeout,
                onload: (response) => {
                    if (response.status === 200) {
                        try {
                            const data = JSON.parse(response.responseText);
                            let reply = data.response;

                            // 清洗 DeepSeek 的 <think> 标签
                            reply = reply.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
                            reply = reply.replace(/[\r\n"]/g, '');

                            console.log("🤖 [AI] 生成完毕:", reply);
                            resolve(reply);
                        } catch (e) { reject("AI解析失败"); }
                    } else {
                        reject("AI状态码: " + response.status);
                    }
                },
                ontimeout: () => reject("⏳ AI 生成超时"),
                onerror: (err) => reject("AI 网络连接失败")
            });
        });
    }

    // 5. 发送评论
    function submitToCSDN(articleId, text) {
        console.log(`📤 [发送] 目标ID: ${articleId} | 内容: ${text}`);

        GM_xmlhttpRequest({
            method: "POST",
            url: CONFIG.submitUrl,
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "Origin": "https://blog.csdn.net",
                "Referer": location.href,
                "Cookie": document.cookie
            },
            data: `commentId=&content=${encodeURIComponent(text)}&articleId=${articleId}`,
            onload: (res) => {
                try {
                    const json = JSON.parse(res.responseText);
                    if (json.code === 200) {
                        console.log("✅ [成功] 评论已发布");
                        // 视觉反馈
                        const box = document.querySelector('.blog-content-box');
                        if(box) box.style.border = "5px solid gold";

                        // 🔥 修改点：使用气泡提示代替 alert
                        showToast(`🎉 评论成功：${text.substring(0, 15)}...`, 'success');

                    } else {
                        console.error("❌ CSDN 返回错误:", json);
                        // 🔥 修改点：使用气泡提示代替 alert
                        showToast(`❌ 发送失败 (${json.code}): ${json.message}`, 'error');
                    }
                } catch(e) {
                    console.error("❌ 响应解析失败:", res.responseText);
                    showToast("❌ 响应解析失败", 'error');
                }
            }
        });
    }

    // ================= 🚀 主程序 =================
    async function main() {
        if (!checkLoginStatus()) return;

        await new Promise(r => setTimeout(r, CONFIG.startDelay));

        const articleId = getArticleId();
        const content = extractContent();

        if (!articleId || !content) {
            console.log("❌ 未找到文章内容或ID");
            return;
        }

        try {
            const reply = await getAIResponse(content);
            if (reply) {
                // 模拟拟人等待
                setTimeout(() => {
                    submitToCSDN(articleId, reply);
                }, 1500);
            }
        } catch (error) {
            console.error("❌ 流程中断:", error);
            // 🔥 修改点：使用气泡提示代替 alert
            showToast(`⚠️ ${error}`, 'error');
        }
    }

    main();

})();