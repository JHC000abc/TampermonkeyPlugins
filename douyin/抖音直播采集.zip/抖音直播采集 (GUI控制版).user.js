// ==UserScript==
// @name         抖音直播采集 (GUI控制版)
// @namespace    http://tampermonkey.net/
// @version      12.0
// @description  采集弹幕、主播信息及在线人数，带漂亮的控制按钮
// @author       You
// @match        https://live.douyin.com/*
// @grant        GM_xmlhttpRequest
// @grant        GM_addStyle
// @connect      *
// ==/UserScript==

(function() {
    'use strict';

    // === 配置 ===
    const API_URL = "http://192.168.2.114:8000/api/receive_comments";
    const MAX_HISTORY_SIZE = 500; // 增加历史记录长度，防止高并发下误判

    // === 全局状态 ===
    let isRunning = false; // 默认不开启，需点击按钮
    let intervalId = null;
    const dedupQueue = [];

    // === 注入 CSS 样式 ===
    GM_addStyle(`
        #dy-scraper-btn {
            position: fixed;
            top: 100px;
            right: 20px;
            z-index: 9999;
            padding: 10px 20px;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 25px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            cursor: pointer;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial;
            font-weight: bold;
            font-size: 14px;
            color: #333;
            transition: all 0.3s ease;
            user-select: none;
            display: flex;
            align-items: center;
            gap: 8px;
            border: 2px solid transparent;
        }
        #dy-scraper-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 6px 20px rgba(0,0,0,0.3);
        }
        #dy-scraper-btn.active {
            background: #e8f5e9;
            border-color: #4caf50;
            color: #2e7d32;
        }
        #dy-scraper-btn.inactive {
            background: #ffebee;
            border-color: #ef5350;
            color: #c62828;
        }
        #dy-scraper-status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #ccc;
            transition: background 0.3s;
        }
        #dy-scraper-btn.active #dy-scraper-status-dot {
            background: #4caf50;
            box-shadow: 0 0 8px #4caf50;
        }
        #dy-scraper-btn.inactive #dy-scraper-status-dot {
            background: #ef5350;
        }
    `);

    // === 创建 GUI 按钮 ===
    function createUI() {
        const btn = document.createElement('div');
        btn.id = 'dy-scraper-btn';
        btn.className = 'inactive';
        btn.innerHTML = `
            <div id="dy-scraper-status-dot"></div>
            <span id="dy-scraper-text">点击开始采集</span>
        `;
        document.body.appendChild(btn);

        // 点击事件
        btn.addEventListener('click', toggleScraper);

        // 简单的拖拽功能
        let isDragging = false;
        let startX, startY, initialLeft, initialTop;

        btn.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            initialLeft = btn.offsetLeft;
            initialTop = btn.offsetTop;
            btn.style.cursor = 'grabbing';
        });

        document.addEventListener('mousemove', (e) => {
            if (isDragging) {
                const dx = e.clientX - startX;
                const dy = e.clientY - startY;
                btn.style.left = `${initialLeft + dx}px`;
                btn.style.top = `${initialTop + dy}px`;
                btn.style.right = 'auto'; // 清除 right 属性以允许左侧定位
            }
        });

        document.addEventListener('mouseup', () => {
            isDragging = false;
            btn.style.cursor = 'pointer';
        });
    }

    // === 开关逻辑 ===
    function toggleScraper() {
        const btn = document.getElementById('dy-scraper-btn');
        const text = document.getElementById('dy-scraper-text');

        if (isRunning) {
            // 停止
            clearInterval(intervalId);
            isRunning = false;
            btn.className = 'inactive';
            text.innerText = '采集已暂停';
            console.log("🛑 采集已停止");
        } else {
            // 开始
            intervalId = setInterval(scrapeData, 500); // 启动轮询
            isRunning = true;
            btn.className = 'active';
            text.innerText = '正在采集...';
            console.log("🚀 采集已开始");
        }
    }

    // === 核心采集逻辑 ===
    function scrapeData() {
        if (!isRunning) return;

        // 选择器配置
        const SEL_ROW = '.NkS2Invn';
        const SEL_NAME = '.v8LY0gZF';
        const SEL_CONTENT = '.cL385mHb';
        const SEL_AUDIENCE = '[data-e2e="live-room-audience"]';
        const SEL_STREAMER = '[data-e2e="live-room-nickname"]';

        const batchComments = [];
        const now = Date.now();

        // 1. 获取主播信息
        let streamerInfo = { name: "未知主播", url: "" };
        try {
            let streamerEl = document.querySelector(SEL_STREAMER);
            if (streamerEl) {
                streamerInfo.name = streamerEl.innerText.trim();
                streamerInfo.url = streamerEl.href || "";
            }
        } catch(e) {}

        // 2. 获取在线人数
        let viewerCountStr = "0";
        try {
            let audienceEl = document.querySelector(SEL_AUDIENCE);
            if (audienceEl) {
                viewerCountStr = audienceEl.innerText.trim();
            }
        } catch (e) {}

        // 3. 抓取评论
        let rows = document.querySelectorAll(SEL_ROW);
        rows.forEach(div => {
            if (div.getAttribute('data-sent')) return;

            try {
                let nameEl = div.querySelector(SEL_NAME);
                let contentEl = div.querySelector(SEL_CONTENT);

                if (nameEl && contentEl) {
                    let cleanName = nameEl.innerText.trim().replace(/[:：]$/, '').trim();
                    let rawContent = contentEl.innerText.trim();

                    if (!cleanName || !rawContent) return;

                    let key = cleanName + "|" + rawContent;

                    // 队列去重
                    if (dedupQueue.includes(key)) {
                        div.setAttribute('data-sent', 'true');
                        return;
                    }

                    // 加入发送列表
                    batchComments.push({
                        "username": cleanName,
                        "content": rawContent,
                        "ts": now,
                        "viewers": viewerCountStr
                    });

                    // 更新队列
                    dedupQueue.push(key);
                    if (dedupQueue.length > MAX_HISTORY_SIZE) {
                        dedupQueue.shift();
                    }

                    div.setAttribute('data-sent', 'true');
                }
            } catch (e) {}
        });

        // 4. 发送数据
        if (batchComments.length > 0) {
            const payload = {
                streamer: streamerInfo,
                data: batchComments
            };

            console.log(`%c[发送] ${streamerInfo.name} | 人数:${viewerCountStr} | 消息:${batchComments.length}`, "color: blue");

            GM_xmlhttpRequest({
                method: "POST",
                url: API_URL,
                headers: { "Content-Type": "application/json" },
                data: JSON.stringify(payload),
                onload: (res) => {},
                onerror: (err) => console.error(`[网络错误]`, err)
            });
        }
    }

    // === 初始化 ===
    // 等待页面加载完成后创建按钮
    window.addEventListener('load', createUI);
    // 如果页面已经加载，直接创建
    if (document.readyState === 'complete') createUI();

})();